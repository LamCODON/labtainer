firefox seedlabsqlinjection.com > /dev/null 2>&1 &
